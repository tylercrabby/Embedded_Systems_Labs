clear
g++ scheduler.cpp
./a.out input.txt output.txt