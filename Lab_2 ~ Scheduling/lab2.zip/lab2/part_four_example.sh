clear
g++ *.cpp scheduler.exe
./scheduler.exe part_four_input.txt part_four_output.txt
