clear
g++ *.cpp -o scheduler.exe
./scheduler.exe part_three_input.txt part_three_output.txt
