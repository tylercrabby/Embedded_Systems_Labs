MADE BY:
Carter Nettesheim
Tyler Crabbs

- report located in 'Lab 2 Report.docx'
- example input file for part 3 is part_three_input.txt
- example input file for part 4 is part_four_input.txt
- after running scheduler.exe you must specify whether to use RM algorithm or EDF algorithm when prompted



COMMANDS:
to run part 3 example code:
	1. run command -> bash part_three_example.sh
	2. specify which algorithm to use
	3. output located in part_three_output.txt

to run part 4 example code:
	1. run command -> bash part_four_example.sh
	2. specify which algorithm to use
	3. output located in part_four_output.txt

to compile scheduler.exe
	1. run command -> g++ *.cpp -o scheduler.exe

to run scheduler.exe
	1. run command -> ./scheduler.exe <input file> <output file>
	** must have and input file and output file **
